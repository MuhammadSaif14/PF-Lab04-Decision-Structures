#include <stdio.h>
int main(){

	int a,b,c;
	
	printf("Enter the three sides: \n");	
	scanf("%d %d %d",&a, &b, &c);

	if(a < b+c && b < a+c && c < a+b){
		if(a==b && b==c)
			printf("Equilateral");
		else if((a==b && a != c) || (a==c && a!=c) || (b==c && b != a))
			printf("Isoceles");
		else
			printf("Scalene");
	}else
		printf("Not a Valid Triangle");

	return 0;
}