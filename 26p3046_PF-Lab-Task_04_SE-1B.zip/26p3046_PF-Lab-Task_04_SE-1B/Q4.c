#include <stdio.h>
int main(){

	float weight, height, BMI;
	
	printf("Enter Your Weight: \n");
	scanf("%f", &weight);
	printf("Enter Your Height: \n");
	scanf("%f", &height);

	BMI = weight/ (height*height);

	if(BMI < 18.5)
		printf("Underweight");
	else if((BMI >= 18.5) && (BMI < 25))
		printf("Normal");
	else if((BMI >= 25) && (BMI < 30))
		printf("Overweight");
	else 
		printf("Obese");


	return 0;
}