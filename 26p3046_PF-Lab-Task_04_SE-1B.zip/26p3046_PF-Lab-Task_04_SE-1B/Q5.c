#include <stdio.h>
int main(){

	int a,b,c;

	printf("Enter value a: ");
	scanf("%d", &a);
	printf("Enter value b: ");
	scanf("%d", &b);
	printf("Enter value c: ");
	scanf("%d", &c);

	if(a > b){
		if(a > c)
			printf("'A' has largest value: %d", a);
		else 
			printf("'C' has largest value: %d", c);
			
	}else{
		if(b > a){
			if(b > c)
				printf("'B' has largest value: %d", b);
			else 
				printf("'C' has largest value: %d", c);
		}else
			printf("'A' has largest value: %d", a);
	}
			


	return 0;
}